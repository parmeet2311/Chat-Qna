export type OpenAIModel = {
  name: string;
  id: string;
  available: boolean;
};
